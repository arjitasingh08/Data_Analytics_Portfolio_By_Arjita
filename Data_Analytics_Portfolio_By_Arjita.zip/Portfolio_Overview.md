# 📚 Arjita Singh – Data Analytics Portfolio

## 👩‍💻 About Me
I’m a commerce and management graduate (B.Com in Taxation, PGDM in Finance & Marketing) with a strong interest in **data-driven business decision-making**.
Through my Data Science training and hands-on projects, I’ve developed skills in **SQL, Power BI, Excel, and Python** to analyze data, create dashboards, and derive actionable insights.

## 🧩 Projects Overview

| Project Name | Tools Used | Description |
|---------------|------------|-------------|
| 🎬 **Amazon Prime Video Dashboard** | Power BI, Excel | Analyzed 9,600+ titles by genre, rating, release year, and country to identify content distribution trends. |
| 👥 **HR Analytics Dashboard** | Power BI, DAX, Excel | Examined employee attrition (16.12%) and demographics to identify HR retention trends. |
| 🍕 **Pizza Sales Dashboard (SQL + Power BI)** | SQL, Power BI, Excel | Combined SQL queries and visualization to analyze sales performance, top pizzas, and revenue trends. |
| 🛍️ **Vrinda Store Annual Report 2022** | Excel | Created an interactive dashboard analyzing gender-based sales, order status, and state-wise performance. |

## 🛠️ Tools & Skills
- **Data Visualization:** Power BI, Excel
- **Data Analysis:** SQL, Python (Basics), Pandas, NumPy
- **Reporting & Dashboarding:** Power BI, DAX, Excel Charts
- **Database Management:** Microsoft SQL Server
- **Soft Skills:** Analytical Thinking, Communication, Finance Knowledge

## 🏆 Certifications
- Microsoft SQL Server Masterclass (Beginner to Advanced) – *Udemy*
- Power BI for Business Intelligence – *Udemy*
- Essential SQL: SQL Window Functions for Business Analytics – *Udemy*
- Data Science Certification (AnalytixLabs – Ongoing)

## 🌐 Connect with Me
📍 **Location:** Jabalpur, Madhya Pradesh
💼 **LinkedIn:** [Your LinkedIn URL]
💻 **GitHub:** [Your GitHub URL]
✉️ **Email:** [Your Email ID]

⭐ *This portfolio demonstrates my journey of transforming from a commerce & management background to a data-driven analyst, bridging the gap between business understanding and analytical insights.*
