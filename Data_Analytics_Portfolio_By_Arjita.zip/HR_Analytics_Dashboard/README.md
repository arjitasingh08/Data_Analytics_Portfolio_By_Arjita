# 👥 HR Analytics Dashboard

## 🎯 Project Objective
To identify employee attrition patterns and understand key factors like age, gender, department, and education field influencing workforce retention.

## 🧩 Dataset Used
**File Name:** `HR_Data.xlsx`
**Records:** 1,470 employees
**Fields:** Age, Gender, Department, Job Role, Education, Job Satisfaction, Attrition

## 🧮 Key Metrics
- **Overall Employees:** 1,470
- **Active Employees:** 1,233
- **Attrition:** 237
- **Attrition Rate:** 16.12%
- **Average Age:** 37 years

## 📊 Dashboard Insights
- **Highest Attrition:** R&D Department (54.12%)
- **Education Impact:** Life Sciences and Medical fields show higher attrition.
- **Age Distribution:** Majority of attrition occurs in the 25–34 age group.
- **Gender Ratio:** Balanced workforce with slightly higher attrition among males.
- **Job Satisfaction:** Visible correlation between lower satisfaction and higher attrition.

## 🛠️ Tools Used
- **Power BI** (Visualization)
- **DAX** (KPIs & Measures)
- **Power Query** (Data Cleaning)
- **Excel** (Pre-processing)

## 💡 Business Impact
Helps HR departments identify high-risk groups, improve employee engagement, and reduce attrition through data-backed decisions.

## 🏁 Outcome
Delivered an analytical dashboard that provides actionable insights into employee retention, demographics, and job satisfaction.
