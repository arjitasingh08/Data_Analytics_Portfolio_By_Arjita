# 🛍️ Vrinda Store Annual Report 2022 (Excel Dashboard)

## 🎯 Project Objective
To analyze sales and order performance data of Vrinda Store for 2022 and identify trends across gender, channels, and locations.

## 🧩 Dataset Used
**File Name:** `Vrinda_Store_Data.xlsx`
**Fields:** Order Date, Gender, State, Channel, Category, Amount, Age Group

## 🧮 Key Metrics
- **Top States:** Maharashtra, Karnataka, Uttar Pradesh, Telangana, Tamil Nadu
- **Top Channels:** Amazon (35.5%), Flipkart (23.4%), Meesho (21.6%)
- **Sales by Gender:** Women (64%) vs Men (36%)
- **Order Status:** 92% delivered, 4% returned, 3% cancelled

## 📊 Dashboard Insights
- Majority of sales come from **female customers** in top 5 states.
- **Amazon and Flipkart** are the most successful sales channels.
- **Adults (35%)** and **young customers (34%)** form the major buyer segment.
- Peak sales occur in **March, May, and November**.

## 🛠️ Tools Used
- **Microsoft Excel**
- Pivot Tables, Pivot Charts, Conditional Formatting
- Interactive Slicers for filtering by state, month, and category

## 💡 Business Impact
Supports management in identifying top-performing states, customer demographics, and best-performing sales channels.

## 🏁 Outcome
Built an interactive Excel dashboard summarizing Vrinda Store’s annual sales and performance for data-driven marketing and inventory planning.
