# 🍕 Pizza Sales Performance Dashboard (SQL + Power BI)

## 🎯 Project Objective
To analyze pizza store sales performance, customer buying behavior, and revenue trends using SQL for analysis and Power BI for visualization.

## 🧩 Dataset Used
**File Name:** `pizza_sales.xlsx`
**Data Fields:** Order Date, Pizza Name, Category, Size, Quantity, Price, Total Amount

## 🧮 Key Metrics
- **Total Revenue:** ₹817.86K
- **Total Orders:** 21,350
- **Total Pizzas Sold:** 49,574
- **Average Pizzas per Order:** 2.32

## 📊 Dashboard Insights
- **Peak Sales:** On weekends (Friday–Sunday).
- **Top Months:** July and January show maximum orders.
- **Best Category:** Classic pizzas contribute highest sales.
- **Top Sizes:** Large pizzas have maximum demand.
- **Top Sellers:** Supreme and Veggie pizzas lead overall sales.

## 🛠️ Tools Used
- **SQL Server** (Data Querying and Analysis)
- **Power BI** (Visualization)
- **Excel** (Data Cleaning & Input Source)

## 💡 Business Impact
Helps business owners track revenue trends, top-performing pizzas, and customer preferences, supporting better marketing and inventory decisions.

## 🏁 Outcome
Delivered a data-driven dashboard combining SQL and Power BI to visualize pizza sales and performance insights effectively.
